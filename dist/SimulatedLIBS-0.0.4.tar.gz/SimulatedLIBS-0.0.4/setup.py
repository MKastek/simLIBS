import setuptools

setuptools.setup(
    name='SimulatedLIBS',
    version='0.0.4',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='Marcin Kastek',
    author_email='marcin.kastek.stud@pw.edu.pl',
    description='LIBS'
)