import setuptools

setuptools.setup(
    name='libs',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='Marcin Kastek',
    author_email='marcin.kastek.stud@pw.edu.pl',
    description='LIBS'
)